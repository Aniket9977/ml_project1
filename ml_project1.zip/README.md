# ml_project1
# end to end ML project 

# if you get any error like importing any module then add src at the starting of location
#deployment using a DockerFile